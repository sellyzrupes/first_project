source venv/bin/activate
python client.py