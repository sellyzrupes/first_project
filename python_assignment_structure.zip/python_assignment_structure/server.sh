export FLASK_APP=server.py
flask run --host 127.0.0.1 --port 8000
